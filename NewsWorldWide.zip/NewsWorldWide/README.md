# NewsWorldWide
News Android App  I am using following technologies
- Clean Architecture
- MVVM
- Kotlin Coroutines,
- Kotlin
- Koin Dependency Injection
- LiveData
- ViewModel
- DataBinding
